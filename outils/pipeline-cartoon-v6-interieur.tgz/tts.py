"""Usage: tts.py VOICE_ID out.mp3 'texte' [model]  — clé lue dans le fichier rtf/key, jamais affichée."""
import re,sys,json,urllib.request
K=re.findall(r'sk_[A-Za-z0-9]{20,}',open('__import__('sys').argv[0].rsplit('/',1)[0]+'/../elevenlabs.rtf' if False else '/mnt/user-data/uploads/Claude-memoire/LICLOC/Marketing/outils/elevenlabs.rtf'',errors='ignore').read())[-1]
vid,out,txt=sys.argv[1],sys.argv[2],sys.argv[3]; model=sys.argv[4] if len(sys.argv)>4 else 'eleven_v3'
st=json.loads(sys.argv[5]) if len(sys.argv)>5 else {"stability":0.5,"similarity_boost":0.85}
body=json.dumps({"text":txt,"model_id":model,"voice_settings":st}).encode()
r=urllib.request.Request(f'https://api.elevenlabs.io/v1/text-to-speech/{vid}?output_format=mp3_44100_128',data=body,headers={'xi-api-key':K,'Content-Type':'application/json'})
try:
    d=urllib.request.urlopen(r,timeout=120).read(); open(out,'wb').write(d); print('ok',len(d))
except urllib.error.HTTPError as e: print('ERR',e.code,e.read()[:300].decode())
