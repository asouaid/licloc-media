import sys,json,re,subprocess
from PIL import Image,ImageDraw,ImageFont
from specs import V,NB
W,H,FPS=1080,1920,30
FD='/home/claude/fonts/use/';_c={}
def F(w,s):
    k=(w,s)
    if k not in _c:_c[k]=ImageFont.truetype(f'{FD}poppins-latin-{w}-normal.woff',s)
    return _c[k]
WHITE=(255,255,255);LIME=(198,240,107)
def cl(x):return max(0.,min(1.,x))
def eo(x):x=cl(x);return 1-(1-x)**3
def back(x):
    x=cl(x);c1=1.70158;c3=c1+1;return 1+c3*(x-1)**3+c1*(x-1)**2
def A(c,a):return (*c[:3],int(255*cl(a)))
def tc(d,x,y,s,f,fill,sw=4):d.text((x,y),s,font=f,fill=fill,anchor='ma',stroke_width=sw,stroke_fill=(5,7,18,int(fill[3]*.88)))
def wrap(d,s,f,mw):
    out,cur=[],''
    for w in s.split(' '):
        t=(cur+' '+w).strip()
        if d.textlength(t,font=f)>mw and cur:out.append(cur);cur=w
        else:cur=t
    if cur:out.append(cur)
    return out
def chunks(txt,t0,t1):
    parts=[p.strip() for p in re.split(r'(?<=[.!?…:])\s+',txt) if p.strip()]
    out=[];cur=''
    for p in parts:
        if cur and len(cur)+len(p)>44:out.append(cur);cur=p
        else:cur=(cur+' '+p).strip()
    if cur:out.append(cur)
    tot=sum(len(p) for p in out);t=t0;res=[]
    for p in out:d=(t1-t0)*len(p)/tot;res.append((t,t+d,p));t+=d
    return res
GR=Image.new('RGBA',(W,H),(0,0,0,0));_d=ImageDraw.Draw(GR)
for y in range(1150,1920):_d.line([(0,y),(W,y)],fill=(4,6,16,int(150*min(1,(y-1150)/420))))
class Comp:
    def __init__(s,k):
        s.k=k;s.v=V[k];tl=json.load(open(f'tl_{k}.json'));s.T=tl['T'];s.L=tl['lines'];s.caps=[]
        for l in s.L[1:]:s.caps+=chunks(l['cap'],l['t0'],l['t1'])
    def frame(s,im,t):
        im=im.convert('RGBA');L=Image.new('RGBA',(W,H),(0,0,0,0));d=ImageDraw.Draw(L)
        h0=s.L[0]['t1']+.05
        if t<=h0+.2:
            a=1 if t<h0 else 1-eo((t-h0)/.2);sc=1+.06*(1-eo(t/.25)) if t<.25 else 1
            fs=90
            while max(d.textlength(l,font=F(700,fs)) for l in s.v['hook'])>960:fs-=2
            for i,l in enumerate(s.v['hook']):tc(d,W/2,1360+i*int(fs*1.24),l,F(700,int(fs*sc)),A(LIME if i==len(s.v['hook'])-1 else WHITE,a),5)
        for j,(a0,a1,tx) in enumerate(s.caps):
            nx=s.caps[j+1][0] if j+1<len(s.caps) else 99
            end=a1+.12 if nx-a1>.15 else nx
            if a0-.02<=t<end:
                u=t-a0;sc=back(u/.18) if u<.18 else 1;a=eo(u/.06)
                f=F(600,int(60*(.9+.1*sc)));ls=wrap(d,tx,F(600,60),920);y0=1470-(len(ls)-1)*40
                for i,l in enumerate(ls):tc(d,W/2,y0+i*82,l,f,A(WHITE,a))
        if t>=s.T+.05:
            u=t-s.T;a=eo(u/.35);sc=.92+.08*eo(u/.35)
            txt="Commente "+s.v['cta'];f=F(600,int(64*sc));tw=d.textlength(txt,font=f)
            pw,ph=tw+110,int(128*sc);x0,y0=W/2-pw/2,1500-ph/2
            P=Image.new('RGBA',(W,H),(0,0,0,0));pd=ImageDraw.Draw(P)
            pd.rounded_rectangle([x0,y0,x0+pw,y0+ph],ph/2,fill=(198,240,107,int(245*a)))
            pd.text((W/2,y0+ph/2),txt,font=f,fill=(10,12,16,int(255*a)),anchor='mm')
            pd.text((W/2,y0+ph+34),"newsletter gratuite",font=F(500,34),fill=(255,255,255,int(230*a)),anchor='ma')
            L.alpha_composite(P)
        im.alpha_composite(GR);im.alpha_composite(L);return im.convert('RGB')
if __name__=='__main__':
    k=sys.argv[1];c=Comp(k)
    if sys.argv[2]=='test':
        ts=[float(x) for x in sys.argv[3:]];S=Image.new('RGB',(270*len(ts),480))
        for i,t in enumerate(ts):S.paste(c.frame(Image.open(f'st_{k}_{int(round(t*FPS))}.jpg'),t).resize((270,480)),(270*i,0))
        S.save(f'cc_{k}.png');sys.exit()
    out=sys.argv[2];n=json.load(open(f'tl_{k}.json'))['nf']
    p=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','rawvideo','-pix_fmt','rgb24','-s',f'{W}x{H}','-r',str(FPS),'-i','-','-i',f'audio_{k}.wav','-map','0:v','-map','1:a','-c:v','libx264','-preset','medium','-crf','20','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-shortest','-movflags','+faststart',out],stdin=subprocess.PIPE)
    for i in range(n):p.stdin.write(c.frame(Image.open(f'fr_{k}/{i:05d}.jpg'),i/FPS).tobytes())
    p.stdin.close();p.wait();print('ok',k)
