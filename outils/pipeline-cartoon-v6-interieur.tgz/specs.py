# INTÉRIEUR (bureau le soir) : Nathan (H) + mascotte Victor (M)
NB = " "
V = {}
V['vide'] = dict(cta='VIDE', scene='bureau', hook=["Ton appart reste vide", "combien de temps" + NB + "?"],
title="Entre deux locataires, ton appart reste vide combien de temps ?",
lines=[
('H', "[curious] Entre deux locataires... ton appart reste vide combien de temps ?", f"Entre deux locataires… ton appart reste vide combien de temps{NB}?", 'curious', [(0, 'q', 'pop', 'overH')]),
('M', "En moyenne, vingt-quatre jours.", f"En moyenne{NB}: 24 jours.", 'jump', [(.2, 'cal', 'jumpout', 'groundL')]),
('H', "Trois semaines ? C'est rien, ça !", f"Trois semaines{NB}? C'est rien, ça{NB}!", 'happy', []),
('M', "Pas si vite. Un studio loué six cents euros par mois : quatre cent quatre-vingts euros de loyer perdus.", f"Pas si vite. Un studio à 600{NB}€ par mois{NB}: 480{NB}€ de loyer perdus.", 'wave', [(.25, 'house', 'pop', 'overM'), (.7, 'coin', 'rain', 'ground')]),
('H', "[surprised] Quatre cent quatre-vingts euros ?!", f"480{NB}€{NB}?!", 'surprised', [(0, 'ex', 'pop', 'overH')]),
('M', "Sur l'année, ton rendement brut passe de six à cinq virgule six pour cent.", f"Sur l'année, ton rendement brut passe de 6{NB}% à 5,6{NB}%.", 'spin', [(.3, 'pct', 'pop', 'mid'), (.75, 'down', 'pop', 'overM')]),
('H', "[curious] Et comment on évite ça ?", f"Et comment on évite ça{NB}?", 'curious', []),
('M', "Tu prépares la relocation dès le préavis : annonce, photos, visites. Envoie ça à quelqu'un qui loue un appart. Commente VIDE pour la newsletter gratuite.", "Tu prépares la relocation dès le préavis : annonce, photos, visites. Envoie ça à quelqu'un qui loue un appart. Commente VIDE pour la newsletter gratuite.", 'cta', [(.08, 'key', 'jumpout', 'groundR'), (.3, 'check', 'pop', 'overM')]),
],
caption="")
ORDER = ['vide']
SPK = 'HM'
SEP = " ... ... ... "
def voice_text(k, spk): return SEP.join(l[1] for l in V[k]['lines'] if l[0] == spk)
if __name__ == '__main__':
    for s in SPK: print(s, len(voice_text('vide', s))); print(voice_text('vide', s))
