import json,re,subprocess,wave
from specs import V,ORDER,SPK
def sil(f):
    o=subprocess.run(f'ffmpeg -i {f} -af silencedetect=noise=-38dB:d=0.2 -f null -',shell=True,capture_output=True,text=True).stderr
    st=[float(x) for x in re.findall(r'silence_start: ([\d.]+)',o)];en=[float(x) for x in re.findall(r'silence_end: ([\d.]+)',o)]
    if len(en)<len(st):en.append(9e9)
    return list(zip(st,en))
def dur(f):
    w=wave.open(f);return w.getnframes()/w.getframerate()
seg={}
for spk in SPK:
    f=f'{spk}.wav';D=dur(f);S=sil(f)
    lines=[(k,l) for k in ORDER for l in V[k]['lines'] if l[0]==spk];n=len(lines)
    ch=[len(re.sub(r'\[.*?\]|\.\.\.','',l[1]).strip()) for k,l in lines]
    st=S[0][1] if S and S[0][0]<0.05 else 0.0
    end=S[-1][0] if S and S[-1][1]>=D-0.05 else D
    C=[(a,min(b,D)) for a,b in S if a>st+0.2 and b<end-0.1 and b-a>=0.25]
    tot=sum(ch);exp=[c/tot*(end-st) for c in ch]
    m=len(C);INF=1e18
    # dp[i][j]: lignes 0..i finies, coupure i au silence j
    def cost(i,a,b):d=b-a;e=exp[i];return ((d-e)/max(.6,e))**2
    dp=[[INF]*m for _ in range(n-1)];bk=[[-1]*m for _ in range(n-1)]
    for j in range(m):dp[0][j]=cost(0,st,C[j][0])-0.8*(C[j][1]-C[j][0])
    for i in range(1,n-1):
        for j in range(m):
            for p in range(j):
                if dp[i-1][p]<INF:
                    v=dp[i-1][p]+cost(i,C[p][1],C[j][0])-0.8*(C[j][1]-C[j][0])
                    if v<dp[i][j]:dp[i][j]=v;bk[i][j]=p
    best=min(range(m),key=lambda j:dp[n-2][j]+cost(n-1,C[j][1],end))
    cuts=[best]
    for i in range(n-2,0,-1):cuts.append(bk[i][cuts[-1]])
    cuts=cuts[::-1];b=[st]+[x for j in cuts for x in C[j]]+[end]
    for idx,((k,l)) in enumerate(lines):
        a,bb=b[2*idx],b[2*idx+1];seg.setdefault(f'{k}_{spk}',[]).append((a,bb));print(f'{k}_{spk} {a:6.2f}-{bb:6.2f} {bb-a:5.2f}/{exp[idx]:5.2f} {l[2][:50]}')
json.dump(seg,open('seg.json','w'))
