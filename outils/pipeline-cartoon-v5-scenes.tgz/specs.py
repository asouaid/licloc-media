# (locuteur H=Nathan, F=Victoria, M=mascotte Victor ; texte voix ; sous-titre ; humeur ; événements[(frac, kind, motion, where)])
NB=" "
V={}
V['parking']=dict(cta='PARKING',scene='rue2',hook=["Une place de parking…","ça rapporte plus qu'un appart"+NB+"?"],
title="Une place de parking, ça rapporte plus qu'un appart ?",
lines=[
('H',"[curious] Une place de parking... ça rapporte plus qu'un appart ?",f"Une place de parking… ça rapporte plus qu'un appart{NB}?",'curious',[(0,'q','pop','overH')]),
('F',"Sérieux ? Juste pour garer une voiture ?",f"Sérieux{NB}? Juste pour garer une voiture{NB}?",'curious',[]),
('M',"Souvent, oui. Une place à vingt mille euros, louée cent euros par mois.",f"Souvent, oui. Une place à 20{NB}000{NB}€, louée 100{NB}€ par mois.",'jump',[(.3,'car','jumpout','groundL'),(.8,'coin','pop','mid')]),
('H',"[excited] Six pour cent brut ?!",f"6{NB}% brut{NB}?!",'surprised',[(0,'ex','pop','overH')]),
('M',"Et pas de DPE, pas d'encadrement des loyers, presque pas de travaux.","Et pas de DPE, pas d'encadrement des loyers, presque pas de travaux.",'spin',[(.15,'check','pop','mid'),(.6,'doc','pop','overM')]),
('F',"[serious] Et le piège ?",f"Et le piège{NB}?",'worried',[]),
('M',"Ça prend peu de valeur. En Île-de-France, plus deux virgule six pour cent en dix ans, contre près de quatorze pour les appartements.",f"Ça prend peu de valeur. En Île-de-France : +2,6{NB}% en 10 ans, contre +13,9{NB}% pour les apparts.",'wave',[(.3,'house','pop','overM'),(.75,'down','pop','mid')]),
('M',"Envoie ça à quelqu'un qui veut investir petit. Commente PARKING pour la newsletter gratuite.","Envoie ça à quelqu'un qui veut investir petit. Commente PARKING pour la newsletter gratuite.",'cta',[(.08,'car','jumpout','groundR'),(.3,'check','pop','overM')]),
],
caption="Une place de parking, ça rapporte plus qu'un appart ?\nEnvoie ça à quelqu'un qui veut investir petit.\nExemple illustratif : une place à 20 000 €, louée 100 €/mois, c'est 6 % brut. Pas de DPE, pas d'encadrement des loyers (bail du Code civil), peu de charges. Mais peu de plus-value : +2,6 % en 10 ans en Île-de-France contre +13,9 % pour les appartements. Et avec les ZFE et moins de voitures en ville, l'emplacement compte plus que tout.\n💬 Commente PARKING et on t'envoie l'accès à notre newsletter gratuite.\nContenu éducatif, pas un conseil personnalisé. Rendement brut avant frais, taxe foncière et impôts. Sources : Notaires du Grand Paris (sept. 2025), Calcunet et Finary (2026).\n#parking #investissementlocatif #immobilier #rendementlocatif #patrimoine")
V['saison']=dict(tempo=1.07,cta='SAISON',scene='neige',hook=["Tu loues ton studio au ski","aux vacanciers"+NB+"?"],
title="Tu loues ton studio au ski ? L'impôt a changé (meublé de tourisme)",
lines=[
('F',"[curious] Tu loues ton studio au ski aux vacanciers ?",f"Tu loues ton studio au ski aux vacanciers{NB}?",'curious',[(0,'q','pop','overF')]),
('H',"Oui, douze mille euros par an. Pourquoi ?",f"Oui, 12{NB}000{NB}€ par an. Pourquoi{NB}?",'curious',[(.4,'coin','pop','overH')]),
('M',"Depuis la loi Le Meur, s'il n'est pas classé, tu n'as plus que trente pour cent d'abattement.",f"Loi Le Meur{NB}: s'il n'est pas classé, plus que 30{NB}% d'abattement.",'jump',[(.2,'doc','jumpout','groundL'),(.75,'pct','pop','mid')]),
('H',"[surprised] Trente pour cent seulement ?!",f"30{NB}% seulement{NB}?!",'surprised',[(0,'ex','pop','overH')]),
('M',"Tu es imposé sur huit mille quatre cents euros. Avant, c'était six mille.",f"Imposé sur 8{NB}400{NB}€. Avant{NB}: 6{NB}000{NB}€.",'wave',[(.5,'down','pop','mid')]),
('F',"Et comment on fait ?",f"Et comment on fait{NB}?",'curious',[]),
('M',"Tu le fais classer, avec des étoiles. Là, c'est cinquante pour cent d'abattement. Imposé sur six mille euros.",f"Fais-le classer en étoiles{NB}: 50{NB}% d'abattement. Imposé sur 6{NB}000{NB}€.",'spin',[(.1,'star','rain','ground'),(.7,'check','pop','overM')]),
('H',"[excited] Deux mille quatre cents euros de moins à déclarer !",f"2{NB}400{NB}€ de moins à déclarer{NB}!",'happy',[(.2,'coin','pop','overH')]),
('M',"Le classement se paie, et se renouvelle tous les cinq ans. Envoie ça à quelqu'un qui loue à la montagne. Commente SAISON pour la newsletter gratuite.","Le classement se paie, et se renouvelle tous les cinq ans. Envoie ça à quelqu'un qui loue à la montagne. Commente SAISON pour la newsletter gratuite.",'cta',[(.08,'star','pop','overM'),(.35,'cal','pop','mid')]),
],
caption="Tu loues ton studio au ski aux vacanciers ?\nEnvoie ça à quelqu'un qui loue à la montagne.\nDepuis la loi Le Meur, en micro-BIC, un meublé de tourisme non classé n'a plus que 30 % d'abattement (plafond 15 000 € de recettes). Exemple illustratif : 12 000 € de loyers, imposé sur 8 400 € contre 6 000 € avant. Classé en étoiles : 50 % d'abattement (plafond 83 600 € en 2026), imposé sur 6 000 €. Le classement est payant et valable 5 ans.\n💬 Commente SAISON et on t'envoie l'accès à notre newsletter gratuite.\nContenu éducatif, pas un conseil personnalisé. Hors prélèvements sociaux. Sources : loi n° 2024-1039 du 19/11/2024, service-public.gouv.fr (juil. 2026).\n#locationsaisonniere #meubledetourisme #lmnp #immobilier #fiscalite")
V['coloc']=dict(cta='COLOC',scene='parc',hook=["Même appart…","presque 2× plus de loyer"+NB+"?"],
title="Même appart, presque 2 fois plus de loyer ? (la colocation)",
lines=[
('H',"[curious] Même appart... presque deux fois plus de loyer ?",f"Même appart… presque deux fois plus de loyer{NB}?",'curious',[(0,'q','pop','overH')]),
('F',"Impossible. C'est quoi le truc ?",f"Impossible. C'est quoi le truc{NB}?",'curious',[]),
('M',"La colocation. Un T4 loué entier, environ mille cent euros. En colocation, quatre chambres.",f"La colocation. Un T4 loué entier{NB}: environ 1{NB}100{NB}€. En coloc{NB}: 4 chambres.",'jump',[(.2,'house','jumpout','groundL'),(.75,'key','pop','mid')]),
('F',"À combien la chambre ?",f"À combien la chambre{NB}?",'curious',[]),
('M',"En moyenne, cinq cent huit euros en France. Quatre chambres, plus de deux mille euros par mois.",f"508{NB}€ en moyenne en France. 4 chambres{NB}: plus de 2{NB}000{NB}€ par mois.",'spin',[(.15,'coin','rain','ground'),(.7,'bed','pop','mid')]),
('H',"[excited] Presque le double ?!",f"Presque le double{NB}?!",'surprised',[(0,'ex','pop','overH')]),
('F',"[serious] Et le piège ?",f"Et le piège{NB}?",'worried',[]),
('M',"Neuf mètres carrés minimum par chambre, des meubles, des départs fréquents, et beaucoup plus de gestion. Envoie ça à quelqu'un qui veut investir. Commente COLOC pour la newsletter gratuite.",f"9{NB}m² minimum par chambre, des meubles, des départs fréquents, et beaucoup plus de gestion. Envoie ça à quelqu'un qui veut investir. Commente COLOC pour la newsletter gratuite.",'cta',[(.05,'doc','pop','overM'),(.25,'down','pop','mid')]),
],
caption="Même appart, presque 2 fois plus de loyer ?\nEnvoie ça à quelqu'un qui veut investir.\nExemple illustratif : un T4 loué entier autour de 1 100 €/mois ; en colocation, 4 chambres au loyer moyen de 508 €, soit plus de 2 000 €/mois. En échange : 9 m² minimum par chambre, logement meublé, rotation des locataires, plus de gestion. En zone d'encadrement, la somme des loyers reste plafonnée.\n💬 Commente COLOC et on t'envoie l'accès à notre newsletter gratuite.\nContenu éducatif, pas un conseil personnalisé. Sources : LocService 2025, service-public.gouv.fr, décret 2002-120.\n#colocation #investissementlocatif #immobilier #rendementlocatif #lmnp")
ORDER=['parking','saison','coloc']
SPK='HFM'
SEP=" ... ... ... "
def voice_text(k,spk):return SEP.join(l[1] for l in V[k]['lines'] if l[0]==spk)
if __name__=='__main__':
    import json
    out={k:{s:voice_text(k,s) for s in SPK} for k in ORDER}
    full={s:SEP.join(out[k][s] for k in ORDER) for s in SPK}
    json.dump(full,open('voice_texts.json','w'),ensure_ascii=False,indent=0)
    for s in SPK:print(s,len(full[s]),len(full[s].split()))
    print(sum(len(full[s]) for s in SPK))
