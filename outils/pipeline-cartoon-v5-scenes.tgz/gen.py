import json,sys,math,subprocess,wave,random
import numpy as np
from specs import V,ORDER,SPK
SR=44100;FPS=30;GAP=.12;TAIL=2.5;HOOKTEMPO=1.12
def rd(f):
    w=wave.open(f);return np.frombuffer(w.readframes(w.getnframes()),dtype='int16').astype(float)/32768
def cl(x):return max(0.,min(1.,x))
def eo(x):x=cl(x);return 1-(1-x)**3
def back(x):
    x=cl(x);c1=1.70158;c3=c1+1;return 1+c3*(x-1)**3+c1*(x-1)**2
def sfx(kind):
    t=np.arange(int(SR*{'pop':.12,'coin':.35,'whoosh':.32,'boing':.3}[kind]))/SR
    if kind=='pop':f=500+2200*t/t[-1];y=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*38)
    elif kind=='coin':y=(np.sin(2*np.pi*1900*t)+.6*np.sin(2*np.pi*2850*t))*np.exp(-t*14)*.6
    elif kind=='whoosh':
        n=np.random.RandomState(3).randn(len(t));k=np.ones(25)/25;n=np.convolve(n,k,'same');y=n*np.sin(np.pi*t/t[-1])**2*.9
    else:f=170+260*t/t[-1]+25*np.sin(2*np.pi*18*t);y=np.sin(2*np.pi*np.cumsum(f)/SR)*np.exp(-t*9)
    return y/np.abs(y).max()
SFX={k:sfx(k) for k in ['pop','coin','whoosh','boing']}
# positions : Nathan x=-1.7, Victoria x=+1.7, mascotte x=0 devant (z=1.1) sur un socle
CAM={'W':(0,3.5,12.6,0,2.75,0),'H':(-.5,4.2,6.1,-1.75,3.55,0),'F':(.5,4.2,6.1,1.75,3.55,0),'M':(.4,3.15,7.6,0,2.55,1.1)}
FOV={'W':45,'H':38,'F':38,'M':38}
ANCH={'overH':(-1.45,4.95,.5),'overF':(1.45,4.95,.5),'overM':(.05,3.75,1.6),'ground':(0,.3,2.3),'groundL':(-.9,.35,2.4),'groundR':(.9,.35,2.4)}
MID={'W':(0,4.2,2.0),'H':(-1.15,4.05,1.9),'F':(1.15,4.05,1.9),'M':(.85,3.35,3.2)}
JSTART=(0,2.5,1.5)
def build(k):
    v=V[k];seg=json.load(open('seg.json'))
    trk={s:rd(f'{s}.wav') for s in SPK};idx={s:0 for s in SPK}
    clips=[];t=0.0;L=[]
    for i,l in enumerate(v['lines']):
        s=l[0];a,b=seg[f'{k}_{s}'][idx[s]];idx[s]+=1
        x=trk[s][int(a*SR):int(b*SR)]
        tp=v.get('tempo',1)*(HOOKTEMPO if i==0 else 1)
        if tp!=1:
            subprocess.run(f'ffmpeg -y -loglevel error -ss {a} -t {b-a} -i {s}.wav -af atempo={tp} -ar 44100 -ac 1 clip_{k}.wav',shell=True,check=True);x=rd(f'clip_{k}.wav')
        d=len(x)/SR;clips.append((s,x,t));L.append(dict(i=i,spk=s,t0=t,t1=t+d,cap=l[2],mood=l[3],ev=l[4]));t+=d+GAP
    T=t-GAP;N=int((T+TAIL)*SR);tr={s:np.zeros(N) for s in SPK}
    for s,x,t0 in clips:
        a=int(t0*SR);n=min(len(x),N-a);f=int(.01*SR);e=np.ones(n);e[:f]=np.linspace(0,1,f);e[-f:]=np.linspace(1,0,f);tr[s][a:a+n]+=x[:n]*e
    pk={s:np.percentile(abs(tr[s][tr[s]!=0]),99.5) for s in tr}
    voice=sum(tr[s]*.5/pk[s] for s in tr)
    nf=int((T+TAIL)*FPS);env={}
    hop=SR//FPS
    for s in tr:
        vv=np.array([np.sqrt((tr[s][max(0,i*hop-hop//2):i*hop+hop//2]**2).mean()) for i in range(nf)]);p=np.percentile(vv[vv>1e-5],95);env[s]=np.clip(vv/p,0,1)
    def shot_of(l):
        if l['i']==0 or l['mood']=='cta' or any(e[2] in('rain','jumpout') for e in l['ev']):return 'W'
        return l['spk']
    shots=[(l['t0']-.06 if l['i'] else 0,shot_of(l)) for l in L]
    props=[];sfxev=[];rnd=random.Random(7)
    for l in L:
        dl=l['t1']-l['t0'];sh=shot_of(l)
        for j,(fr,kind,mo,wh) in enumerate(l['ev']):
            te=l['t0']+fr*dl;life_end=max(l['t1']+.35,te+1.6)
            base=MID[sh] if wh=='mid' else ANCH[wh]
            pid=f"{l['i']}_{j}"
            if mo=='pop':
                props.append(dict(id=pid,k=kind,mo='pop',t0=te,t1=life_end,p=base,s=(.8 if (wh=='mid' and sh=='M') else 1.25 if sh=='W' else 1.0)));sfxev.append((te,'pop',.5))
            elif mo=='jumpout':
                props.append(dict(id=pid,k=kind,mo='jump',t0=te,t1=life_end+.6,p=base,s=1.6));sfxev.append((te,'whoosh',.35));sfxev.append((te+.55,'pop',.45))
            elif mo=='rain':
                for c in range(16):
                    tc=te+c*.06;p=(rnd.uniform(-1.6,1.6),.3,rnd.uniform(1.7,2.8))
                    props.append(dict(id=f'{pid}_{c}',k=kind,mo='rain',t0=tc,t1=life_end+.5,p=p,s=1.6,ry=rnd.uniform(0,6.28)))
                    if c%3==0:sfxev.append((tc+.45,'coin',.22))
    def next_nonW(t0):
        for a,c in shots:
            if a>t0+.05 and c!='W':return a
        return 9e9
    for q in props:
        if q['mo'] in('jump','rain'):q['t1']=min(q['t1'],next_nonW(q['t0']))
    def prop_state(q,t):
        if t<q['t0'] or t>q['t1']:return None
        a=t-q['t0'];x,y,z=q['p'];rest=q['t1']-t
        out=lambda s,**kw:dict(id=q['id'],k=q['k'],x=kw.get('x',x),y=kw.get('y',y),z=kw.get('z',z),s=s,rx=kw.get('rx',0),ry=kw.get('ry',0),rz=kw.get('rz',0))
        sh=min(1,rest/.2)
        if q['mo']=='pop':return out(q['s']*back(a/.32)*sh,y=y+.05*math.sin(a*4),ry=.5*math.sin(a*1.6))
        if q['mo']=='jump':
            st=JSTART
            if a<.55:
                u=a/.55;return out(q['s']*(.4+.6*u),x=st[0]+(x-st[0])*u,y=st[1]+(y-st[1])*u+1.5*math.sin(math.pi*u),z=st[2]+(z-st[2])*u,ry=u*6.28)
            b2=a-.55;bo=abs(math.sin(b2*9))*.25*math.exp(-b2*4);sq=1+.18*math.exp(-b2*7)*math.sin(b2*20)
            return out(q['s']*sh*sq,y=y+bo)
        if q['mo']=='rain':
            fall=.5
            if a<fall:u=a/fall;return out(q['s'],y=7.5-(7.5-y)*u*u,ry=q['ry']+a*12,rx=1.2)
            b2=a-fall;bo=abs(math.sin(b2*10))*.3*math.exp(-b2*5)
            return out(q['s']*sh,y=y+bo,rx=1.5708,ry=q['ry'])
    for l in L:
        if l['spk']=='M' and l['i']>0 and l['mood'] in('jump','spin'):sfxev.append((l['t0'],'boing',.18))
        if l['mood']=='surprised':sfxev.append((l['t0'],'boing',.3))
    for a,c in shots[1:]:sfxev.append((a,'whoosh',.12))
    frames=[]
    def lin(l,t):return l['t0']<=t<l['t1']+GAP
    for f in range(nf):
        t=f/FPS;sh=[c for a,c in shots if a<=t][-1];c=list(CAM[sh]);st=max(a for a,cc in shots if a<=t);k2=t-st
        d=.014*min(k2,8);c[2]-=d*(.9 if sh!='W' else .6)
        cur=[l for l in L if lin(l,t)];cl_=cur[0] if cur else None
        fov=FOV[sh];shake=0
        if cl_ and cl_['mood']=='surprised':
            u=t-cl_['t0'];fov-=5*math.exp(-u*3)*(u>0);shake=.05*math.exp(-u*6)
        if shake:c[0]+=shake*math.sin(t*90);c[1]+=shake*math.cos(t*77)
        # personnages : regard vers celui qui parle
        spk=cl_['spk'] if cl_ else 'M'
        P={}
        for who,base in (('H',.35),('F',-.35)):
            other={'H':'F','F':'H'}[who]
            tgt=base if spk=='M' else (base*1.9 if spk==other else base*.4)
            P[who]=dict(turn=tgt,nod=0,brow=0,wide=False,jump=0,lean=0,gest=0)
        mTurn=0;mHop=0;mJump=0;mSpin=0;mWave=0;mWaveR=0
        if spk=='H':mTurn=-.45
        if spk=='F':mTurn=.45
        if cl_:
            u=t-cl_['t0'];m=cl_['mood'];s=cl_['spk']
            if s in 'HF':
                q=P[s];q['gest']=.6+.4*math.sin(t*3.1)
                if m=='surprised':q['jump']=.32*max(0,math.sin(math.pi*min(u/.4,1)));q['wide']=True;q['lean']=-.06;q['gest']=1
                if m=='worried':q['brow']=.32;q['nod']=.1
                if m=='happy':q['jump']=.14*max(0,math.sin(math.pi*min(u/.35,1)));q['nod']=-.08
                if m=='curious':q['nod']=-.06;q['brow']=-.15
            else:
                mHop=.12*max(0,math.sin(math.pi*min(u/.3,1)))
                if m=='jump':mJump=.55*max(0,math.sin(math.pi*min(u/.55,1)))
                if m=='spin':mSpin=6.283*eo(u/.7);mJump=.25*max(0,math.sin(math.pi*min(u/.7,1)))
                if m=='wave':mWave=min(1,u/.3)
                if m=='cta':k3=eo(u/.4);mWave=k3;mWaveR=k3*(1 if u>1.2 else 0);P['H']['turn']=.55;P['F']['turn']=-.55
        if t>=T:
            mTurn=0;mWave=1;mWaveR=1
            for who in 'HF':P[who]['turn']=0;P[who]['gest']=.9
        pr=[x for x in (prop_state(q,t) for q in props) if x]
        frames.append(dict(t=round(t,4),eH=round(float(env['H'][f]),3),eF=round(float(env['F'][f]),3),eM=round(float(env['M'][f]),3),cam=c,fov=fov,H=P['H'],F=P['F'],mTurn=mTurn,mHop=mHop,mJump=mJump,mSpin=mSpin,mWave=mWave,mWaveR=mWaveR,props=pr))
    json.dump(frames,open(f'frames_{k}.json','w'))
    mix=voice.copy()
    for te,kind,g in sfxev:
        a=int(te*SR);x=SFX[kind]*g*.35;n=min(len(x),N-a)
        if a<N and n>0:mix[a:a+n]+=x[:n]
    mix=mix/np.abs(mix).max()*.95
    w=wave.open(f'audio_{k}.wav','wb');w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes((mix*32767).astype('int16').tobytes());w.close()
    json.dump(dict(T=T,nf=nf,lines=L),open(f'tl_{k}.json','w'),ensure_ascii=False)
    print(k,'durée',round(T+TAIL,2),'images',nf,'accessoires',len(props))
if __name__=='__main__':
    for k in (sys.argv[1:] or ORDER):build(k)
