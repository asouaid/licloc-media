import json,sys,base64,re
out=sys.argv[1];s=''
for f in sys.argv[2:]:
    t=json.load(open(f))[0]['text']
    t=t.split('\n\n(captured')[0].strip()
    if t.startswith('"'):t=json.loads(t)
    s+=t
print(len(s));open(out,'wb').write(base64.b64decode(s))
