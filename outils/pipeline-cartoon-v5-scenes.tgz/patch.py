s=open('ep6.html').read()
CAR='''function car(x,z,col,ry=0){const g=new THREE.Group();box(2.6,.55,1.25,col,0,.55,0,g);box(1.5,.5,1.15,col,-.1,1.05,0,g);box(1.42,.4,1.18,new THREE.MeshStandardMaterial({color:0x2b3550,flatShading:true,roughness:.2,metalness:.3}),-.1,1.05,0,g,{noc:1});
 [[-.85,.62],[.85,.62],[-.85,-.62],[.85,-.62]].forEach(([wx,wz])=>{const w=add(new THREE.CylinderGeometry(.3,.3,.22,10),0x1a1a1e,wx,.3,wz,g);w.rotation.x=Math.PI/2});
 box(.06,.16,.3,M(0xfff2c0,1.2),1.31,.62,.38,g,{noc:1});box(.06,.16,.3,M(0xfff2c0,1.2),1.31,.62,-.38,g,{noc:1});box(.06,.14,.28,M(0xff3a3a,.9),-1.31,.62,.38,g,{noc:1});box(.06,.14,.28,M(0xff3a3a,.9),-1.31,.62,-.38,g,{noc:1});
 g.position.set(x,0,z);g.rotation.y=ry;s.add(g);return g}
'''
s=s.replace("const anim=[];","const anim=[];\n"+CAR,1)
NEIGE=r'''if(SCENE==='neige'){
  s.fog=new THREE.Fog(0xdde9f5,20,70);
  sky([[0,'#2f6fd0'],[.4,'#7fb2ea'],[.5,'#d7e8f7'],[.56,'#eef4fb'],[1,'#f4f8fc']]);
  const gg=new THREE.PlaneGeometry(80,80,40,40);gg.rotateX(-Math.PI/2);jitter(gg,.3);const gp=gg.attributes.position;for(let i=0;i<gp.count;i++){const x=gp.getX(i),z=gp.getZ(i);if(Math.abs(x)<4&&z>-3&&z<6)gp.setY(i,0)}gg.computeVertexNormals();
  const ground=new THREE.Mesh(gg,new THREE.MeshStandardMaterial({color:0xf2f6fb,flatShading:true,roughness:.9}));ground.receiveShadow=true;s.add(ground);
  // montagnes enneigées
  for(let i=0;i<8;i++){const h=14+R()*12,rr=9+R()*6;const x=-42+i*12,z=-50-R()*8;const m=add(new THREE.ConeGeometry(rr,h,6),[0x6d7f99,0x5f7290,0x7a8ca6][i%3],x,h/2-3,z,0,{noc:1});const cap=add(new THREE.ConeGeometry(rr*.42,h*.42,6),0xffffff,x,h-3-h*.21,z,0,{noc:1});cap.rotation.y=m.rotation.y}
  // sapins enneigés
  const snowTree=(x,z,h)=>{const t=conifer(x,z,h);t.children.slice(1).forEach((c,i)=>{const sc=add(new THREE.ConeGeometry((.5-i*.12)*h,.32*h,6),0xffffff,0,c.position.y+.25*h,0,t,{noc:1})});return t};
  for(let i=0;i<90;i++){let x=(R()-.5)*46,z=-5-R()*30;if(i<30){x=(R()<.5?-1:1)*(5+R()*9);z=-3+R()*7}if(Math.abs(x)<4&&z>-7)continue;snowTree(x,z,1.6+R()*2.4)}
  snowTree(-5,3.4,3.4);snowTree(5.6,2.6,3.0);snowTree(6.6,-1.8,3.4);snowTree(-6.4,-1.6,2.8);
  // chalets
  const chalet=(x,z,k,ry)=>{const g=new THREE.Group();box(3,2,2.4,0x8a5a36,0,1,0,g);for(let i=0;i<5;i++)box(3.04,.05,2.44,0x6a4428,0,.3+i*.4,0,g,{noc:1});
    const rf=new THREE.Shape();rf.moveTo(-1.9,0);rf.lineTo(0,1.5);rf.lineTo(1.9,0);rf.lineTo(-1.9,0);const rg=new THREE.ExtrudeGeometry(rf,{depth:2.9,bevelEnabled:false});rg.translate(0,0,-1.45);rg.rotateY(Math.PI/2);add(rg,0xffffff,0,2,0,g);
    [-.8,.8].forEach(wx=>box(.6,.6,.06,M(0xffc66a,1),wx,1.25,1.22,g,{noc:1}));box(.7,1.2,.06,0x4a2e1c,0,.6,1.22,g,{noc:1});box(.35,.8,.35,0x6d6a70,.9,3.1,0,g);
    g.position.set(x,0,z);g.scale.setScalar(k);g.rotation.y=ry;s.add(g);return g};
  chalet(-7.5,-6,1.3,.35);chalet(7.8,-7,1.4,-.3);chalet(-1.5,-11,1.6,0);chalet(13,-12,1.3,-.2);
  // télésiège au loin
  for(let i=0;i<5;i++)add(new THREE.CylinderGeometry(.12,.15,6,5),0x55606e,-20+i*9,3+i*1.6,-30-i*3,0,{noc:1});
  // skis plantés + bonhomme de neige
  [[3.2,2.8],[3.5,2.9]].forEach(([x,z],i)=>{const k=box(.12,2,.05,i?0xe25640:0x3e8ae0,x,1,z);k.rotation.z=(i?-1:1)*.12});
  add(new THREE.IcosahedronGeometry(.55,1),0xffffff,-3.3,.5,2.6);add(new THREE.IcosahedronGeometry(.38,1),0xffffff,-3.3,1.25,2.6);add(new THREE.ConeGeometry(.06,.3,5),0xf08a2a,-3.3,1.25,2.98).rotation.x=Math.PI/2;
  [-.12,.12].forEach(x=>box(.06,.06,.04,0x1a1a1a,-3.3+x,1.38,2.93,0,{noc:1}));
  // socle : bloc de neige / caisse en bois
  box(1.5,.9,1.3,0x8a5a36,0,.45,1.1);box(1.62,.14,1.42,0xffffff,0,.95,1.1);
  cloud(-14,22,-40,2.4);cloud(12,26,-46,3);
  s.add(new THREE.HemisphereLight(0xdfeeff,0x9fb0c8,.9));
  const sun=new THREE.DirectionalLight(0xfff1d8,2.3);sun.position.set(-8,12,7);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-9,right:9,top:9,bottom:-9,near:1,far:40});s.add(sun);
  const fill=new THREE.DirectionalLight(0xd8e6ff,.6);fill.position.set(4,4,10);s.add(fill);
  // flocons
  const fx=[];for(let i=0;i<90;i++){const m=add(new THREE.IcosahedronGeometry(.04+R()*.04,0),M(0xffffff,.8),0,0,0,0,{noc:1});fx.push([m,R()*10,R()*10-5,R()*7-1.5,R()*8]);}
  anim.push(t=>fx.forEach(([m,ph,x0,z0,y0])=>{m.position.set(x0+Math.sin(t*.8+ph)*.4,8-((y0+t*.7)%8.5),z0+Math.cos(t*.6+ph)*.3)}));
}else if(SCENE==='parc'){
  s.fog=new THREE.Fog(0xf3d9b0,20,70);
  sky([[0,'#4f8fd8'],[.42,'#a8cdee'],[.5,'#f7e2b8'],[.56,'#f5cf94'],[1,'#eebf86']]);
  const gg=new THREE.PlaneGeometry(80,80,40,40);gg.rotateX(-Math.PI/2);jitter(gg,.12);const gp=gg.attributes.position;for(let i=0;i<gp.count;i++){const x=gp.getX(i),z=gp.getZ(i);if(Math.abs(x)<4&&z>-3&&z<6)gp.setY(i,0)}gg.computeVertexNormals();
  const gcol=new Float32Array(gp.count*3);const ca=new THREE.Color(0x8fae4a),cb=new THREE.Color(0xa7a64a),tc=new THREE.Color();for(let i=0;i<gp.count;i++){tc.copy(ca).lerp(cb,R());gcol.set([tc.r,tc.g,tc.b],i*3)}gg.setAttribute('color',new THREE.BufferAttribute(gcol,3));
  const ground=new THREE.Mesh(gg,new THREE.MeshStandardMaterial({vertexColors:true,flatShading:true,roughness:1}));ground.receiveShadow=true;s.add(ground);
  // allée en gravier
  box(4.2,.04,40,0xdcc8a0,0,.02,-10,0,{noc:1});box(40,.04,3,0xdcc8a0,0,.02,-6.5,0,{noc:1});
  // immeubles parisiens au fond
  let X=-30;const cols=[0xefe2c8,0xe9d7b6,0xf3e7d2,0xe4d1ae];
  for(let b=0;b<14;b++){const w=4.2+R()*1.2,fl=5+Math.floor(R()*2),h=fl*1.9+.6;const g=new THREE.Group();g.position.set(X+w/2,0,-24);s.add(g);box(w,h,1,cols[b%4],0,h/2,0,g,{noc:1});
    const rf=add(new THREE.CylinderGeometry(.01,w*.62,1.6,4),0x5d6878,0,h+.8,0,g,{noc:1});rf.rotation.y=Math.PI/4;rf.scale.z=.3;
    for(let f=0;f<fl;f++)for(let k=0;k<3;k++){const lit=R()<.3;box(.7,1.05,.06,new THREE.MeshStandardMaterial({color:lit?0xffd38a:0x56607a,emissive:lit?0xffb35a:0,emissiveIntensity:lit?.8:0,flatShading:true}),(k-1)*w*.3,1.4+f*1.9,.52,g,{noc:1});if(f===1||f===4)box(w*.9,.06,.3,0x2a2a30,0,1.4+f*1.9-.55,.6,g,{noc:1})}
    X+=w+.1}
  // arbres d'automne
  const AUT=[0xe0892a,0xd2552e,0xe8b43a,0xc9452a,0x9fb848];
  for(let i=0;i<60;i++){let x=(R()-.5)*44,z=-3-R()*18;if(i<26){x=(R()<.5?-1:1)*(4.5+R()*9);z=-2+R()*7}if(Math.abs(x)<3.2&&z>-8)continue;if(Math.abs(z+6.5)<2)continue;roundTree(x,z,1.6+R()*1.8,AUT[i%5])}
  roundTree(-5,3.2,2.6,0xe0892a);roundTree(5.4,2.8,2.4,0xd2552e);roundTree(6.4,-1.8,2.8,0xe8b43a);roundTree(-6.2,-2,2.6,0xc9452a);
  // bancs, lampadaires, fontaine
  const bench=(x,z,ry)=>{const g=new THREE.Group();box(1.8,.08,.5,0x3e6b4a,0,.55,0,g);box(1.8,.4,.06,0x3e6b4a,0,.85,-.24,g);[-.8,.8].forEach(k=>box(.08,.55,.45,0x22262c,k,.28,0,g));g.position.set(x,0,z);g.rotation.y=ry;s.add(g)};
  bench(-3.4,-1.2,.5);bench(3.6,-1.4,-.5);
  [[-3,2.4],[3.2,2.4],[-3,-5],[3,-5]].forEach(([x,z])=>{add(new THREE.CylinderGeometry(.07,.1,3.6,6),0x1f2a2a,x,1.8,z);box(.4,.5,.4,M(0xffe2a0,1.1),x,3.8,z,0,{noc:1})});
  add(new THREE.CylinderGeometry(1.6,1.8,.5,12),0xcfc4b2,0,.25,-9);add(new THREE.CylinderGeometry(1.4,1.4,.06,12),M(0x6fb6d8,.25,.2),0,.5,-9,0,{noc:1});add(new THREE.CylinderGeometry(.15,.25,1.4,8),0xcfc4b2,0,1,-9);
  // socle : piédestal en pierre
  box(1.5,.9,1.3,0xcfc4b2,0,.45,1.1);box(1.62,.1,1.42,0xb8ad9a,0,.93,1.1);
  cloud(-14,22,-40,2.4);cloud(12,25,-46,3);cloud(26,19,-38,2);
  s.add(new THREE.HemisphereLight(0xdfe9ff,0x8a7a4a,.8));
  const sun=new THREE.DirectionalLight(0xffdca0,2.4);sun.position.set(-8,11,6);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-9,right:9,top:9,bottom:-9,near:1,far:40});s.add(sun);
  const fill=new THREE.DirectionalLight(0xfff0dc,.6);fill.position.set(4,4,10);s.add(fill);
  // feuilles qui tombent
  const fx=[];for(let i=0;i<50;i++){const m=add(new THREE.PlaneGeometry(.12,.08),new THREE.MeshStandardMaterial({color:AUT[i%4],side:THREE.DoubleSide,flatShading:true}),0,0,0,0,{noc:1});fx.push([m,R()*10,R()*9-4.5,R()*6-1,R()*7]);}
  anim.push(t=>fx.forEach(([m,ph,x0,z0,y0])=>{m.position.set(x0+Math.sin(t*.9+ph)*.7,7-((y0+t*.5)%7),z0+Math.cos(t*.6+ph)*.4);m.rotation.set(t*2+ph,t*1.5,ph)}));
  // pigeons
  const pig=[[-2.6,2.2],[2.8,1.9]].map(([x,z])=>{const g=new THREE.Group();box(.3,.22,.18,0x8a8f99,0,.13,0,g);box(.14,.14,.14,0x6b7080,.17,.27,0,g);box(.06,.03,.04,0xe8a33a,.27,.27,0,g);g.position.set(x,0,z);s.add(g);return g});
  anim.push(t=>pig.forEach((g,i)=>{g.rotation.y=Math.sin(t*.8+i*2)*1.2;g.children[1].position.y=.27+Math.abs(Math.sin(t*4+i))*.04}));
}else{'''
s=s.replace("}else{\n  // RUE AU COUCHER DU SOLEIL","}else "+NEIGE+"\n  // RUE AU COUCHER DU SOLEIL",1)
# rue2 : pas de grand-mère, voitures garées + panneau P
old="  const grand=new THREE.Group();gw.add(grand);"
assert old in s
s=s.replace(old,"  const grand=new THREE.Group();gw.add(grand);if(SCENE==='rue2')grand.visible=false;",1)
old2="  // socle de la mascotte : borne/jardinière"
assert old2 in s
s=s.replace(old2,"""  if(SCENE==='rue2'){car(-7.2,3.6,0x3e8ae0);car(-10.2,3.6,0xe9c46a);car(7.4,3.6,0xe25640);car(10.6,3.6,0xf3efe4);car(-13,3.6,0x2f6d6a);
    for(let i=-5;i<6;i++)box(.08,.02,1.2,0xe8e4d8,i*3,-.11,3.6,0,{noc:1});
    add(new THREE.CylinderGeometry(.06,.06,2.6,6),0x55606e,-4.2,1.3,2.2);box(.8,.8,.08,M(0x2f6fd0,.4),-4.2,2.8,2.22);box(.1,.5,.1,0xffffff,-4.35,2.8,2.28,0,{noc:1});box(.3,.1,.1,0xffffff,-4.22,3.0,2.28,0,{noc:1});box(.1,.28,.1,0xffffff,-4.08,2.9,2.28,0,{noc:1});box(.3,.1,.1,0xffffff,-4.22,2.78,2.28,0,{noc:1});}
  // socle de la mascotte : borne/jardinière""",1)
# tenues
s=s.replace("top:SCENE==='foret'?0x3f6e4a:0x2d4d8c","top:SCENE==='foret'?0x3f6e4a:SCENE==='neige'?0xd9473a:SCENE==='parc'?0x7a5a3a:0x2d4d8c",1)
s=s.replace("top:SCENE==='foret'?0xd9a23a:0xe0684f,sleeve:SCENE==='foret'?0xd9a23a:0xe0684f","top:SCENE==='foret'?0xd9a23a:SCENE==='neige'?0x2f6fd0:SCENE==='parc'?0x3e6b8a:0xe0684f,sleeve:SCENE==='foret'?0xd9a23a:SCENE==='neige'?0x2f6fd0:SCENE==='parc'?0x3e6b8a:0xe0684f",1)
s=s.replace("scarf:SCENE==='foret'?0xf3efe4:null","scarf:SCENE==='foret'?0xf3efe4:SCENE==='neige'?0xf3efe4:SCENE==='parc'?0xe8b43a:null",1)
# accessoires
old3=" tree:()=>{"
s=s.replace(old3,""" car:()=>{const g=G();box(.9,.22,.45,0x3e8ae0,0,0,0,g);box(.5,.2,.42,0x3e8ae0,-.04,.2,0,g);box(.46,.15,.43,0x2b3550,-.04,.2,0,g,{noc:1});[[-.3,.23],[.3,.23],[-.3,-.23],[.3,-.23]].forEach(([x,z])=>{const w=add(new THREE.CylinderGeometry(.11,.11,.08,10),0x1a1a1e,x,-.12,z,g);w.rotation.x=Math.PI/2});return g},
 star:()=>{const g=G();const sh=new THREE.Shape();for(let i=0;i<10;i++){const a=Math.PI/2+i*Math.PI/5,rr=i%2?.12:.28;i?sh.lineTo(Math.cos(a)*rr,Math.sin(a)*rr):sh.moveTo(Math.cos(a)*rr,Math.sin(a)*rr)}const sg=new THREE.ExtrudeGeometry(sh,{depth:.08,bevelEnabled:false});sg.translate(0,0,-.04);const m=new THREE.Mesh(sg,M(0xffd25a,.7,.4));m.castShadow=true;g.add(m);return g},
 bed:()=>{const g=G();box(.7,.14,.42,0x8a5a36,0,-.08,0,g);box(.66,.1,.4,0xf6f3ea,0,.04,0,g);box(.2,.08,.32,0xffffff,-.22,.12,0,g);box(.4,.06,.4,0x3e6b8a,.12,.1,0,g);box(.06,.36,.44,0x8a5a36,-.36,.04,0,g);return g},
 tree:()=>{""",1)
open('ep6.html','w').write(s);print('ok')
